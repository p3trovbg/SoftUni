﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GenericCountMethodString
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            List<Box<string>> strings = new List<Box<string>>();

            for (int i = 0; i < n; i++)
            {
                Box<string> currentBox = new Box<string>(Console.ReadLine());
                strings.Add(currentBox);
            }

            Console.WriteLine(Filter(strings, Console.ReadLine()));
        }

        static int Filter<T>(List<Box<T>> list, T item)
            where T : IComparable
        {
            return list.Count(x => x.Input.CompareTo(item) > 0);
        }
        
    }
}
